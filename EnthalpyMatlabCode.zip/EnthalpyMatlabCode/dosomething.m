

function x = dosomething()

clc

    function y = f_something(c,Tree)
        y=Tree*c.^2;
    end

fun = @(D) exp(1).*f_something(D,10)
integral(fun,0,5)

end