function substance=getsubstances()
    substance=struct('rhoi',{},'Mi',{},'sigmaii',{},'epsiloniikB',{},...
                     'gammai',{},'alpha',{},'name',{});

 
     
     substance(16).name='adipic methylamine salt (2:1)';
     substance(16).Mi=0.2083; 
     substance(16).rhoi=1154.5;  % taken from http://15240.vvchem.com/show-2777802.html;
     substance(16).gammai=0.1; %estimated.
     substance(16).sigmaii=7.22e-10; % based on valderrama calculation
     substance(16).epsiloniikB=646.3;%. Ind. Eng. Chem. Res. 2007, 46, 1338-1344.)
     substance(16).alpha=1;
     
    
    
%%
